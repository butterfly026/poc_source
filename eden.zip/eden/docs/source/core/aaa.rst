Authentication, Authorization and Accounting
============================================

.. Topics to cover
   - Authentication
     - Interactive login - auth/user controller
     - HTTP Basic Auth
     - OAuth2
   - Authorization
     - Policies
     - Realms
     - auth_roles.csv
     - Role Manager

