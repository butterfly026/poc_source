Built-in CRUD Methods
=====================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   REST <rest>
   CRUD <crud>
   Pivottable Reports <report>
   Timeplot Reports <timeplot>
   Spreadsheet Importer <import>


