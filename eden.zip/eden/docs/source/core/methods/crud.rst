Standard Interactive CRUD
=========================

*to be written*

