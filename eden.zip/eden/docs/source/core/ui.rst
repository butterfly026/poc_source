User Interface Elements
=======================

.. Topics to cover
   - Filters
     - URL queries, $filter, $search
     - Widgets
   - Client-side Scripts
     - UI widgets
     - s3.scripts and s3.jquery_ready
   - Forms
     - Widgets
     - Inline-Components etc.
     - Default Form, Custom Form
     - Data Tables, Card Lists
