Implementing Templates
======================

Settings
--------

Customising resources
---------------------

Customising controllers
-----------------------

Pre-populating data
-------------------

Menus
-----

Configuring Auth
----------------

