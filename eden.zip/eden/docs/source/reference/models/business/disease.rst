Disease Tracking
================

This module implements data elements to track disease outbreaks, both
on the individual case level, and in mass testing. It was originally
developed for Ebola Virus Disease outbreaks, and has later been
re-used during the COVID-19 pandemic.

.. image:: er_disease.png
   :align: center

