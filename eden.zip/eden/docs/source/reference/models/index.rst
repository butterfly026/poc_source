Built-in Data Models
====================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Core Models <core/index>
   Extensions <ext/index>
   Business Data Models <business/index>
