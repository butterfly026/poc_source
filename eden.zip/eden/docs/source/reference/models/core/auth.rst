User Accounts and Roles - *auth*
================================

*to be written*
