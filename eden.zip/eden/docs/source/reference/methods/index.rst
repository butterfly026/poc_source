Standard CRUD Methods
=====================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Data Table <datatable>
   Form-based CRUD <crud>
   Map <map>
   Pivottable Report <report>
   Timeplot <timeplot>
   Summary <summary>
   Organizer <organize>
   Spreadsheet Import <import>
