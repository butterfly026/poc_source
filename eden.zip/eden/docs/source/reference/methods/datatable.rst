Data Tables
===========

Tabular view of records (end-point: */list*, and default for table end-point without method and interactive data format).

.. figure:: list_filter.png

   Data Table View with Filter Form
