Summary
=======

Meta-method with multiple other methods on the same page (on tabs),
and a common filter form (end-point: */summary*).

.. figure:: summary.png

   Summary view with table, report and map tabs, and common filter form.

.. note::

   This method requires configuration.
