Map
===

Filterable Map (end-point: */map*).

.. figure:: map_filter.png

   Map with filter form
