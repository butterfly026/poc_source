Organizer
=========

Calendar-based view and manipulation of records (end-point: */organize*)

.. figure:: organize.png

   Organizer (Weekly Agenda View)

.. note::

   This method requires configuration of start and end date fields, as
   well as of popup contents.
