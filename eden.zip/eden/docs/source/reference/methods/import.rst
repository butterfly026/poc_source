Spreadsheet Importer
====================

Interactive Spreadsheet (CSV/XLS) Importer with review and record selection (end-point: */import*).

.. figure:: import_upload.png

   Spreadsheet Importer, Upload Dialog

.. figure:: import_commit.png

   Spreadsheet Importer, Review and Record Selection
