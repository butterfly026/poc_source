Pivottable Reports
==================

User-definable pivot tables with chart option (end-point: */report*).

.. figure:: report.png

   Pivot Table Report

.. figure:: report_charts.png

   Pivot Table with Chart

.. note::

   This method requires configuration.
