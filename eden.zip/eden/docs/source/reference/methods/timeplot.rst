Timeplot
========

Visualisation of the development of a numeric fact over a time axis (endpoint: */timeplot*).

.. figure:: timeplot.png

   Timeplot

.. note::

   This method requires configuration.
