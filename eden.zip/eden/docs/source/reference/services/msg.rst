Messaging *msg*
===============

