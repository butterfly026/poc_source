Adding new themes
=================
