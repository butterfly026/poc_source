Implementing Data Models
========================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   Basic Concepts <basics>
   Defining Tables <tables>
   Table Configuration <configure>
   Reusable Fields <reusablefield>
   Representation Methods <represent>

