Defining Tables
===============

Subclassing S3Model
-------------------

model()
-------

defaults()
----------

mandatory()
-----------

Exposing names
--------------

Defining Tables
---------------
