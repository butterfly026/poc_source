Table Configuration
===================

CRUD Hooks
----------

Linking to Super-Entities
-------------------------

CRUD Strings
------------

Adding Components
-----------------

Adding Methods
--------------
