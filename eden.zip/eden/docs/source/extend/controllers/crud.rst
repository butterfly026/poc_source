Implementing REST Controllers
=============================

rest_controller
---------------

prep
----

postp
-----
