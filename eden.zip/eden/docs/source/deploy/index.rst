How to deploy Sahana Eden applications
======================================

Sahana Eden is normally deployed behind a separate front-end web server (e.g. nginx)
using WSGI/uWSGI to plugin web2py. This section describes how to setup a production
instance of a Sahana Eden application on a Debian server.

.. toctree::
   :maxdepth: 2
   :caption: Contents:
