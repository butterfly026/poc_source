# -*- coding: utf-8 -*-
{
'City': 'Град',
'District': 'Округ',
'Municipality': 'Општина',
'Municipality / City': 'Општина / Град',
'Serbian': 'Српски',
}
