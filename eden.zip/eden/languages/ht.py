# -*- coding: utf-8 -*-
{
'French': 'fransè',
'Haitian Creole': 'kreyòl ayisyen',
'Haitian French': 'fransè ayisyen',
}
