# -*- coding: utf-8 -*-
{
'Municipality': 'општина',
'Macedonian': 'македонски',
'Region': 'регион',
}
