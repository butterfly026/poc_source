# -*- coding: utf-8 -*-
{
'Humanitarian Country Team (HCT) Relief and Rehabilitation System': 'மனிதாபிமான நாடு குழு (HCT) நிவாரண மற்றும் மறுவாழ்வு அமைப்பு',
'Relief and Rehabilitation': 'நிவாரண மற்றும் மறுவாழ்வு',
'Tamil': 'தமிழ்',
}
