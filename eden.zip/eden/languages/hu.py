# -*- coding: utf-8 -*-
{
'County': 'megye',
'District': 'járás',
'Hungarian': 'magyar nyelv',
}
