# -*- coding: utf-8 -*-
{
'Lithuanian': 'Lietuvių',
'County': 'Apskritis',
'Municipality': 'Savivaldybė',
'Eldership': 'Seniūnija',
}
