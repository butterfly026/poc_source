# -*- coding: utf-8 -*-
{
'Chiwog': 'སྤྱི་འོག་',
'District': "རྫོང་ཁག",
'Dzongkha': "རྫོང་ཁ",
'Dzongkhag': "རྫོང་ཁག",
'Gewog': 'རྒེད་འོག',
}
