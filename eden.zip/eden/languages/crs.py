# -*- coding: utf-8 -*-
{
'Seychellois Creole': 'Kreol',
'Sahana First Response': 'Premye Ede Sahana',
}
