# -*- coding: utf-8 -*-
{
'Hindi': 'हिन्दी',
}

