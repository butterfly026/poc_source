import '../src/charts/gv-chart-gauge-progress';
