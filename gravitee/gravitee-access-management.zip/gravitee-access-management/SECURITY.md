# Security Policy

For submission of security vulnerabilities identified in this repo please follow our central process:

https://github.com/gravitee-io/issues/blob/master/SECURITY.md
