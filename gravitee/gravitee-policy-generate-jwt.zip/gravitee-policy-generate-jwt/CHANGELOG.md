# [1.8.0](https://github.com/gravitee-io/gravitee-policy-generate-jwt/compare/1.7.2...1.8.0) (2024-10-07)


### Features

* add secretBase64Encoded for HMAC algorithms ([dd9cfc9](https://github.com/gravitee-io/gravitee-policy-generate-jwt/commit/dd9cfc95010952092fb4875f6c536b405e2bdd3a))

## [1.7.2](https://github.com/gravitee-io/gravitee-policy-generate-jwt/compare/1.7.1...1.7.2) (2023-11-22)


### Bug Fixes

* update the enum value from "PLAIN" to "PEM" in the schema-form.json ([db8a2ae](https://github.com/gravitee-io/gravitee-policy-generate-jwt/commit/db8a2ae0e38f5b7a185656e7b7d96f2eba1b2c83))

## [1.7.1](https://github.com/gravitee-io/gravitee-policy-generate-jwt/compare/1.7.0...1.7.1) (2023-11-09)


### Bug Fixes

* move to `jakarta.xml.bind-api` dependency ([a06efb4](https://github.com/gravitee-io/gravitee-policy-generate-jwt/commit/a06efb48fd742f5cd1aed2df187fea174822d031))

# [1.7.0](https://github.com/gravitee-io/gravitee-policy-generate-jwt/compare/1.6.1...1.7.0) (2023-11-09)


### Features

* add message request phase ([4e28cd6](https://github.com/gravitee-io/gravitee-policy-generate-jwt/commit/4e28cd64830882db18cfd011ea97b76fc7ee16fb))

## [1.6.1](https://github.com/gravitee-io/gravitee-policy-generate-jwt/compare/1.6.0...1.6.1) (2023-07-20)


### Bug Fixes

* update policy description ([94f720f](https://github.com/gravitee-io/gravitee-policy-generate-jwt/commit/94f720fb1dfe72e07332c6ec614be11ba2fe0d64))

# [1.6.0](https://github.com/gravitee-io/gravitee-policy-generate-jwt/compare/1.5.0...1.6.0) (2023-07-05)


### Features

* addition of the execution phase ([7c215e8](https://github.com/gravitee-io/gravitee-policy-generate-jwt/commit/7c215e8d1c089fe6ced5eed6e1d563f7198659ef))
