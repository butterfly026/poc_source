## [3.6.1](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.6.0...3.6.1) (2024-11-04)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-bom to v8.1.17 ([25270e3](https://github.com/gravitee-io/gravitee-cockpit-api/commit/25270e3f6a0adf6190f1b6f536bbf5216aad9cd0))
* **deps:** update io.gravitee:gravitee-parent to v22.2.2 ([590a329](https://github.com/gravitee-io/gravitee-cockpit-api/commit/590a32973fd76471f4f7dc235a6e6e4b5aef37e3))

# [3.6.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.5.0...3.6.0) (2024-10-31)


### Features

* add scope to target token command payload ([#228](https://github.com/gravitee-io/gravitee-cockpit-api/issues/228)) ([da22826](https://github.com/gravitee-io/gravitee-cockpit-api/commit/da2282694de1aefaeab7733f60df7ad124865c64))

# [3.5.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.4.0...3.5.0) (2024-10-30)


### Features

* target token create command and reply ([#227](https://github.com/gravitee-io/gravitee-cockpit-api/issues/227)) ([765831e](https://github.com/gravitee-io/gravitee-cockpit-api/commit/765831e9115d3eefe4d5751f2e9331343ab33a80))

# [3.4.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.3.0...3.4.0) (2024-10-25)


### Features

* spec gen response command and reply ([#225](https://github.com/gravitee-io/gravitee-cockpit-api/issues/225)) ([a4109f5](https://github.com/gravitee-io/gravitee-cockpit-api/commit/a4109f5779d0f500bb69c6c86dd602e72751b6ad))

# [3.3.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.13...3.3.0) (2024-10-18)


### Features

* SpecGenRequest command api ([#223](https://github.com/gravitee-io/gravitee-cockpit-api/issues/223)) ([ce588c4](https://github.com/gravitee-io/gravitee-cockpit-api/commit/ce588c4252a9fdfcf74ff565d6e574b27498bc78))

## [3.2.13](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.12...3.2.13) (2024-10-17)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v6.5.0 ([dc62abc](https://github.com/gravitee-io/gravitee-cockpit-api/commit/dc62abcdecb5ff73963b322f0679cdc4078545a4))

## [3.2.12](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.11...3.2.12) (2024-10-16)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.2.1 ([031b241](https://github.com/gravitee-io/gravitee-cockpit-api/commit/031b241357fea6fe55f50b70978d4873fd7d8176))

## [3.2.11](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.10...3.2.11) (2024-10-14)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v6.4.6 ([cb97224](https://github.com/gravitee-io/gravitee-cockpit-api/commit/cb97224d681dacdf49db208b553332f1e16dbb2e))

## [3.2.10](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.9...3.2.10) (2024-10-09)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.14 ([f720586](https://github.com/gravitee-io/gravitee-cockpit-api/commit/f720586fdb8096ec6f6bed2974f262cbc708cb70))

## [3.2.9](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.8...3.2.9) (2024-10-07)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-bom to v8.1.16 ([1e01235](https://github.com/gravitee-io/gravitee-cockpit-api/commit/1e01235b9671cbbbe13b174e4ec6871f0953460d))

## [3.2.8](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.7...3.2.8) (2024-10-07)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v6.4.5 ([54212da](https://github.com/gravitee-io/gravitee-cockpit-api/commit/54212da7ba15779e12e9823b18ebbaecade40d41))

## [3.2.7](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.6...3.2.7) (2024-10-02)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.13 ([a642d88](https://github.com/gravitee-io/gravitee-cockpit-api/commit/a642d88ac45870a8c64af89049e0a7933e1dc02b))

## [3.2.6](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.5...3.2.6) (2024-09-28)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.12 ([1971f8f](https://github.com/gravitee-io/gravitee-cockpit-api/commit/1971f8fc64827a6b491d1bccbf32a3adacd79445))

## [3.2.5](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.4...3.2.5) (2024-09-26)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.11 ([0849a25](https://github.com/gravitee-io/gravitee-cockpit-api/commit/0849a2583305b9e6d88edefcd927d0c33a139a90))

## [3.2.4](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.3...3.2.4) (2024-09-25)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v6.4.4 ([5f9d372](https://github.com/gravitee-io/gravitee-cockpit-api/commit/5f9d37253ddd0a931daffae001f71ff9e9821b4c))

## [3.2.3](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.2...3.2.3) (2024-09-25)


### Bug Fixes

* **deps:** update gravitee-scoring-api to 0.3.0 ([d2cca50](https://github.com/gravitee-io/gravitee-cockpit-api/commit/d2cca500e5d22b308ddd44e82606bf53756bacaf))

## [3.2.2](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.1...3.2.2) (2024-09-17)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v6.4.3 ([4339cda](https://github.com/gravitee-io/gravitee-cockpit-api/commit/4339cda4a8d719b37eb884dc677de0f0f25f07c7))

## [3.2.1](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.2.0...3.2.1) (2024-09-16)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.10 ([1bbf579](https://github.com/gravitee-io/gravitee-cockpit-api/commit/1bbf5790bd627241d6ea7f8751ae5996a28c896f))

# [3.2.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.1.4...3.2.0) (2024-09-12)


### Features

* add delete environment command ([7835f2f](https://github.com/gravitee-io/gravitee-cockpit-api/commit/7835f2f3da943e9c01174a9fc7a47bc714642bc2))
* add delete organization command ([f37ab48](https://github.com/gravitee-io/gravitee-cockpit-api/commit/f37ab4861a0c6bab66349e5b040f10679143bfff))

## [3.1.4](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.1.3...3.1.4) (2024-09-04)


### Bug Fixes

* **deps:** update io.gravitee.scoring:gravitee-scoring-api to v0.2.0 ([43f96d1](https://github.com/gravitee-io/gravitee-cockpit-api/commit/43f96d1cd86e76ad97fb60806d00dddc1817959b))

## [3.1.3](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.1.2...3.1.3) (2024-09-04)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v6.4.2 ([3e1a498](https://github.com/gravitee-io/gravitee-cockpit-api/commit/3e1a4989e5fcdb3eccad654d3c267ce10bba73ca))

## [3.1.2](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.1.1...3.1.2) (2024-08-30)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v6.4.1 ([2a80f49](https://github.com/gravitee-io/gravitee-cockpit-api/commit/2a80f49b1ec58c0c2cae3bd508d65b1c1632de79))

## [3.1.1](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.1.0...3.1.1) (2024-08-28)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.9 ([d2e8421](https://github.com/gravitee-io/gravitee-cockpit-api/commit/d2e84215b07fa64589234a144a6fc3d8d447e74f))

# [3.1.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.54...3.1.0) (2024-08-20)


### Features

* add scoring service request and response command ([0a37eba](https://github.com/gravitee-io/gravitee-cockpit-api/commit/0a37ebad043a54e11f945410240d3de579d1a17e))

## [3.0.54](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.53...3.0.54) (2024-08-19)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.7 ([73da45e](https://github.com/gravitee-io/gravitee-cockpit-api/commit/73da45eb873cf311e7c5eddea971436de2086f6c))

## [3.0.53](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.52...3.0.53) (2024-08-13)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v6.3.0 ([d8b01d1](https://github.com/gravitee-io/gravitee-cockpit-api/commit/d8b01d15d4239a4097cd00e04fc249614f882f2c))

## [3.0.52](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.51...3.0.52) (2024-08-12)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.6 ([ceffd95](https://github.com/gravitee-io/gravitee-cockpit-api/commit/ceffd950ed0ab31127fc36c3635335a631c5f1e2))

## [3.0.51](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.50...3.0.51) (2024-08-06)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v6.2.0 ([c67fa4b](https://github.com/gravitee-io/gravitee-cockpit-api/commit/c67fa4b113782fda45c31695c86b18167d43f423))

## [3.0.50](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.49...3.0.50) (2024-07-29)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v6.0.4 ([ef336fa](https://github.com/gravitee-io/gravitee-cockpit-api/commit/ef336fa9529998f60a90bc047d6588982158ab91))

## [3.0.49](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.48...3.0.49) (2024-07-26)


### Bug Fixes

* bump exchange framework to 1.8.2 ([6064614](https://github.com/gravitee-io/gravitee-cockpit-api/commit/60646149ec3d969959ba7e522f988a8315a3bf13))

## [3.0.48](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.47...3.0.48) (2024-07-26)


### Bug Fixes

* bump gravitee node to 6.0.3 ([8e3f696](https://github.com/gravitee-io/gravitee-cockpit-api/commit/8e3f6969f8678ec136d85eb72e1f8b22136f8bab))

## [3.0.47](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.46...3.0.47) (2024-07-25)


### Bug Fixes

* bump exchange framework to 1.8.0 ([9608f71](https://github.com/gravitee-io/gravitee-cockpit-api/commit/9608f7151f93998d98e53ce5dd369575598a9ecf))

## [3.0.46](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.45...3.0.46) (2024-07-23)


### Bug Fixes

* bump exchange framework version ([3e1a7d5](https://github.com/gravitee-io/gravitee-cockpit-api/commit/3e1a7d55b66e5ff794a735e5174197289f75b68b))

## [3.0.45](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.44...3.0.45) (2024-07-23)


### Bug Fixes

* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.7.3 ([560877e](https://github.com/gravitee-io/gravitee-cockpit-api/commit/560877ee78dbc81f43ac72537b9dc6625c0844a0))

## [3.0.44](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.43...3.0.44) (2024-07-23)


### Bug Fixes

* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.7.2 ([0963558](https://github.com/gravitee-io/gravitee-cockpit-api/commit/096355833b04c7a0404d90a9321762578526b5ef))

## [3.0.43](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.42...3.0.43) (2024-07-22)


### Bug Fixes

* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.7.1 ([9e6e575](https://github.com/gravitee-io/gravitee-cockpit-api/commit/9e6e57555bdfe916489691608ab6030cfc3a98be))

## [3.0.42](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.41...3.0.42) (2024-07-22)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.5 ([b94a918](https://github.com/gravitee-io/gravitee-cockpit-api/commit/b94a91887a1faab1f4c26aff37f9195fed3a0491))

## [3.0.41](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.40...3.0.41) (2024-07-22)


### Bug Fixes

* bump exchange framework version ([d0bdd3b](https://github.com/gravitee-io/gravitee-cockpit-api/commit/d0bdd3ba21aacc49c76784f5be91ccceb5a811c9))

## [3.0.40](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.39...3.0.40) (2024-07-17)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v5.20.0 ([090f136](https://github.com/gravitee-io/gravitee-cockpit-api/commit/090f13611458cc3c6e47b8b9543d9e2d2d532bf6))

## [3.0.39](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.38...3.0.39) (2024-07-16)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.4 ([511bc05](https://github.com/gravitee-io/gravitee-cockpit-api/commit/511bc054a9b4e8cbe5b65a1e900658b39c8d38ff))

## [3.0.38](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.37...3.0.38) (2024-07-11)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.3 ([fd81519](https://github.com/gravitee-io/gravitee-cockpit-api/commit/fd81519a2e8caed44524ec8cbc68c5caa2ef4d4b))

## [3.0.37](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.36...3.0.37) (2024-07-01)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.1.2 ([6e3c132](https://github.com/gravitee-io/gravitee-cockpit-api/commit/6e3c132732c36427373807cd6e9339559066d56e))

## [3.0.36](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.35...3.0.36) (2024-06-28)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v5.19.0 ([ea3f429](https://github.com/gravitee-io/gravitee-cockpit-api/commit/ea3f4298e1ad634855f3639dd56879256c356595))

## [3.0.35](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.34...3.0.35) (2024-06-27)


### Bug Fixes

* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.6.1 ([8e691b2](https://github.com/gravitee-io/gravitee-cockpit-api/commit/8e691b27630a60bcafc763695eacf91852f79738))

## [3.0.34](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.33...3.0.34) (2024-06-21)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v5.18.2 ([fbf95fd](https://github.com/gravitee-io/gravitee-cockpit-api/commit/fbf95fd202d91af35bc2e8e632e229f09dd3ae19))

## [3.0.33](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.32...3.0.33) (2024-06-20)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v5.18.1 ([3159df4](https://github.com/gravitee-io/gravitee-cockpit-api/commit/3159df485a0eca4385b384967ce8a96dc0c981c4))

## [3.0.32](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.31...3.0.32) (2024-06-19)


### Bug Fixes

* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.6.0 ([7eb580e](https://github.com/gravitee-io/gravitee-cockpit-api/commit/7eb580efd835776d73927cd1a316b58b45d1d4ba))

## [3.0.31](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.30...3.0.31) (2024-06-17)


### Bug Fixes

* **deps:** upgrade gravitee dependencies ([c89a6a6](https://github.com/gravitee-io/gravitee-cockpit-api/commit/c89a6a6e7c92f6be90e1a843e6daf1acbb121d1d))

## [3.0.30](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.29...3.0.30) (2024-06-10)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.0.31 ([53a6d23](https://github.com/gravitee-io/gravitee-cockpit-api/commit/53a6d2376ef8eb563f77d4a8df66085737b6358f))

## [3.0.29](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.28...3.0.29) (2024-05-31)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.0.30 ([0332213](https://github.com/gravitee-io/gravitee-cockpit-api/commit/033221322401bff6f736227bb30d594497ee2d6a))

## [3.0.28](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.27...3.0.28) (2024-05-31)


### Bug Fixes

* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.5.2 ([e5bfad7](https://github.com/gravitee-io/gravitee-cockpit-api/commit/e5bfad781d1c962c50a9f1e63fd44e3e2f6eb7c8))

## [3.0.27](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.26...3.0.27) (2024-05-29)


### Bug Fixes

* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.5.1 ([eb7a4c4](https://github.com/gravitee-io/gravitee-cockpit-api/commit/eb7a4c43cc4c0f784c5a25005f5b20bd519ad6e3))

## [3.0.26](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.25...3.0.26) (2024-05-28)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.0.29 ([e94732e](https://github.com/gravitee-io/gravitee-cockpit-api/commit/e94732e69689515d14a203d5ced38252f9e597e0))

## [3.0.25](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.24...3.0.25) (2024-05-28)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.0.28 ([d8c2394](https://github.com/gravitee-io/gravitee-cockpit-api/commit/d8c23942df03b3b7c1cb3daa66da48463d6588c9))

## [3.0.24](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.23...3.0.24) (2024-05-24)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.0.27 ([06c8d4a](https://github.com/gravitee-io/gravitee-cockpit-api/commit/06c8d4a5c95d1175f98317664db6162fe40ed745))

## [3.0.23](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.22...3.0.23) (2024-04-30)


### Bug Fixes

* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.5.0 ([bc1daa3](https://github.com/gravitee-io/gravitee-cockpit-api/commit/bc1daa3fe500c96539cb02fffc2c179e05e494e0))

## [3.0.22](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.21...3.0.22) (2024-04-22)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.0.26 ([789f13f](https://github.com/gravitee-io/gravitee-cockpit-api/commit/789f13f942f696a43c2484daa3da9bebfa0cbb3c))

## [3.0.21](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.20...3.0.21) (2024-04-17)


### Bug Fixes

* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.4.2 ([baa75e7](https://github.com/gravitee-io/gravitee-cockpit-api/commit/baa75e70ac2b55778b222f27c2a965cf387696e6))

## [3.0.20](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.19...3.0.20) (2024-04-15)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v5.12.4 ([242ccd6](https://github.com/gravitee-io/gravitee-cockpit-api/commit/242ccd6b92c2ebc20443f0513e6204997cea39c6))

## [3.0.19](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.18...3.0.19) (2024-04-15)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-bom to v7.0.23 ([164c521](https://github.com/gravitee-io/gravitee-cockpit-api/commit/164c521e127d4f0ae1e2e3cc7e7b27af6107023a))

## [3.0.18](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.17...3.0.18) (2024-04-12)


### Bug Fixes

* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.4.0 ([29dfae3](https://github.com/gravitee-io/gravitee-cockpit-api/commit/29dfae3c899c29ad2b7d755b66a557915af85e07))
* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.4.1 ([14ce8b5](https://github.com/gravitee-io/gravitee-cockpit-api/commit/14ce8b58613745e9074ce6403c22e9d832e13b53))

## [3.0.17](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.16...3.0.17) (2024-04-12)


### Bug Fixes

* add single target boolean on bridge command ([4eafc5e](https://github.com/gravitee-io/gravitee-cockpit-api/commit/4eafc5e9f3b15f6d624212e28901506f8edd5555))
* create an error simple reply in case of bridge reply in error ([f26a9fc](https://github.com/gravitee-io/gravitee-cockpit-api/commit/f26a9fc06af5199834f62f54b8827363572e0a72))

## [3.0.16](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.15...3.0.16) (2024-04-12)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-bom to v7.0.21 ([306cc00](https://github.com/gravitee-io/gravitee-cockpit-api/commit/306cc008bdd6d6add607d016e8e72b8833944c56))

## [3.0.15](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.14...3.0.15) (2024-04-12)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.0.25 ([2d6d736](https://github.com/gravitee-io/gravitee-cockpit-api/commit/2d6d73677eb0ccc0c1e5f05db10ddaae285bf818))

## [3.0.14](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.13...3.0.14) (2024-04-10)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-bom to v7.0.20 ([9b32d02](https://github.com/gravitee-io/gravitee-cockpit-api/commit/9b32d0221b9421e3b90de01f2b361730f4135f0d))

## [3.0.13](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.12...3.0.13) (2024-04-09)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.0.24 ([7cdec19](https://github.com/gravitee-io/gravitee-cockpit-api/commit/7cdec19826b5b7bfe828e70a79a7e6ffcbc4a651))

## [3.0.12](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.11...3.0.12) (2024-04-05)


### Bug Fixes

* add missing installation id on node healthcheck adapter ([23abb9d](https://github.com/gravitee-io/gravitee-cockpit-api/commit/23abb9d5223728b20e1ca160ab4f69ba77aba665))

## [3.0.11](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.10...3.0.11) (2024-04-05)


### Bug Fixes

* add missing installation id from legacy node command ([44beb7c](https://github.com/gravitee-io/gravitee-cockpit-api/commit/44beb7c9385aae3d09ca4b282fc155f4e9a03d4e))

## [3.0.10](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.9...3.0.10) (2024-04-05)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-bom to v7.0.19 ([ebed808](https://github.com/gravitee-io/gravitee-cockpit-api/commit/ebed8085731a23c6dbb529092cf08bde60393094))

## [3.0.9](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.8...3.0.9) (2024-04-05)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v5.12.2 ([acdcfdf](https://github.com/gravitee-io/gravitee-cockpit-api/commit/acdcfdfbd59e72231ffc28ff391bd61cd39a69eb))

## [3.0.8](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.7...3.0.8) (2024-04-03)


### Bug Fixes

* add missing empty constructor on legacy command ([40c58ae](https://github.com/gravitee-io/gravitee-cockpit-api/commit/40c58ae3359edfde81926b1fa51b447c30a00a44))

## [3.0.7](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.6...3.0.7) (2024-04-03)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v5.12.0 ([876aab9](https://github.com/gravitee-io/gravitee-cockpit-api/commit/876aab9fc40bc609f32f5af0716d08963ede9a44))

## [3.0.6](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.5...3.0.6) (2024-04-02)


### Bug Fixes

* **deps:** update io.gravitee.exchange:gravitee-exchange-api to v1.2.1 ([95c8100](https://github.com/gravitee-io/gravitee-cockpit-api/commit/95c81008d7e4c456e08d5725661077529bc4a32a))

## [3.0.5](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.4...3.0.5) (2024-03-29)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v5.11.0 ([526d453](https://github.com/gravitee-io/gravitee-cockpit-api/commit/526d453dd2db4a5b515f57aa4dda76407581fd46))

## [3.0.4](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.3...3.0.4) (2024-03-28)


### Bug Fixes

* add missing command id when adapting legacy to v1 ([d3e157b](https://github.com/gravitee-io/gravitee-cockpit-api/commit/d3e157b39f10e9672d758d08920c18d3bbb0a864))
* promote API failing ([6b9e84a](https://github.com/gravitee-io/gravitee-cockpit-api/commit/6b9e84a09ad4c913b33018c080dada4873eda727))

## [3.0.3](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.2...3.0.3) (2024-03-27)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.0.23 ([9fccf19](https://github.com/gravitee-io/gravitee-cockpit-api/commit/9fccf1954e4329f507e898a215f2e5604d6345d4))

## [3.0.2](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.1...3.0.2) (2024-03-21)


### Bug Fixes

* use latest exchange framework ([a8ddd82](https://github.com/gravitee-io/gravitee-cockpit-api/commit/a8ddd82c795e24c435eb6c0914ab69b54c2e6ef8))

## [3.0.1](https://github.com/gravitee-io/gravitee-cockpit-api/compare/3.0.0...3.0.1) (2024-03-19)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.0.22 ([773f584](https://github.com/gravitee-io/gravitee-cockpit-api/commit/773f5848747517fe21d84c26d4128cf8457dd119))

# [3.0.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.6.6...3.0.0) (2024-03-19)


### Features

* use new exchange framework ([4baca35](https://github.com/gravitee-io/gravitee-cockpit-api/commit/4baca35d502a38e6dbe5d4e06f9cbaa611c33b26))


### BREAKING CHANGES

* using this version will imply migration on connectors

## [2.6.6](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.6.5...2.6.6) (2024-03-18)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-bom to v7.0.14 ([cdb6f1d](https://github.com/gravitee-io/gravitee-cockpit-api/commit/cdb6f1d32aa2e6f2b5572628eae5c5574861b8a0))

## [2.6.5](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.6.4...2.6.5) (2024-03-18)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v5.10.0 ([199c75b](https://github.com/gravitee-io/gravitee-cockpit-api/commit/199c75b625f94be559ceb5f3377bd024e774acc0))

## [2.6.4](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.6.3...2.6.4) (2024-03-13)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v5.9.1 ([32132c4](https://github.com/gravitee-io/gravitee-cockpit-api/commit/32132c461aedf755acddb33d6b149fc197b67816))

## [2.6.3](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.6.2...2.6.3) (2024-03-11)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-bom to v7.0.13 ([f9b05ed](https://github.com/gravitee-io/gravitee-cockpit-api/commit/f9b05ed7a2d6484327f1c2b722db6869ce6e0106))

## [2.6.2](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.6.1...2.6.2) (2024-02-27)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v22.0.19 ([e2c09d8](https://github.com/gravitee-io/gravitee-cockpit-api/commit/e2c09d83f8f53b1946898f257e4695d7b912f779))

## [2.6.1](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.6.0...2.6.1) (2024-02-27)


### Bug Fixes

* **deps:** upgrade gravitee dependencies ([dc84b13](https://github.com/gravitee-io/gravitee-cockpit-api/commit/dc84b136ec6bdfa64bfd40a5f35e3327213a5236))

# [2.6.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.5.0...2.6.0) (2024-02-27)


### Features

* add commands to disable environment and organization ([6dab25b](https://github.com/gravitee-io/gravitee-cockpit-api/commit/6dab25b1ba58a45d44aea8282d1c07c7957c2e0d))

# [2.5.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.4.0...2.5.0) (2023-12-21)


### Features

* add unlink installation command ([36d1418](https://github.com/gravitee-io/gravitee-cockpit-api/commit/36d14183fdf3d71d51d61a4c2c31c28dd0332012))

# [2.4.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.3.0...2.4.0) (2023-12-18)


### Features

* update organization command payload to add license ([809cbb3](https://github.com/gravitee-io/gravitee-cockpit-api/commit/809cbb3b8d8958b3004f11ee72b9251d89247c08))

# [2.3.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.2.0...2.3.0) (2023-11-14)


### Features

* add new attributes to HelloPayload ([1e8f1ce](https://github.com/gravitee-io/gravitee-cockpit-api/commit/1e8f1ceb3f9cafffeb078a5ed5808ae5b5a5c2ba))

# [2.2.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.1.0...2.2.0) (2023-09-27)


### Bug Fixes

* upgrade prettier version ([40a1a62](https://github.com/gravitee-io/gravitee-cockpit-api/commit/40a1a626e79b1d67a16c28be6fb79209912c30d9))


### Features

* add access points to organization and environment commands ([a691f34](https://github.com/gravitee-io/gravitee-cockpit-api/commit/a691f343fbcb533f16c7b7e94cda8616a1850d9e))

# [2.1.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/2.0.0...2.1.0) (2023-07-10)


### Features

* added V4Api command, payload and reply ([45ff1d0](https://github.com/gravitee-io/gravitee-cockpit-api/commit/45ff1d058bedc61a9bb18f2191de8f9f0003b863))

# [2.0.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.13.8...2.0.0) (2022-12-12)


### chore

* bump to rxJava3 ([b01868f](https://github.com/gravitee-io/gravitee-cockpit-api/commit/b01868fda084d830ca7edaafa5edbde0752fcabd))


### BREAKING CHANGES

* rxJava3 required

# [2.0.0-alpha.1](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.13.6...2.0.0-alpha.1) (2022-10-18)


### chore

* bump to rxJava3 ([b01868f](https://github.com/gravitee-io/gravitee-cockpit-api/commit/b01868fda084d830ca7edaafa5edbde0752fcabd))


### BREAKING CHANGES

* rxJava3 required
 
## [1.13.8](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.13.7...1.13.8) (2022-11-21)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v1.27.3 ([20caf38](https://github.com/gravitee-io/gravitee-cockpit-api/commit/20caf38376409551efa538acff5cb1d55b4091d3))

## [1.13.7](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.13.6...1.13.7) (2022-10-20)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v1.27.2 ([bf82808](https://github.com/gravitee-io/gravitee-cockpit-api/commit/bf8280847db7ea270fab32877fe62883b09d346e))

## [1.13.6](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.13.5...1.13.6) (2022-10-13)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-bom to v2.8 ([a32b785](https://github.com/gravitee-io/gravitee-cockpit-api/commit/a32b7850166269cef2b57b4c8681f9874eb0a34d))

## [1.13.5](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.13.4...1.13.5) (2022-10-13)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v20.5 ([6ebe36b](https://github.com/gravitee-io/gravitee-cockpit-api/commit/6ebe36be9e83d511280e3573a44c5025eb8c6676))
* **deps:** update io.gravitee.node:gravitee-node-api to v1.27.1 ([2a25f24](https://github.com/gravitee-io/gravitee-cockpit-api/commit/2a25f24ce2b7006a069346d177ab182623a397d1))

## [1.13.4](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.13.3...1.13.4) (2022-09-12)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v1.26.0 ([947464f](https://github.com/gravitee-io/gravitee-cockpit-api/commit/947464f22668b4601645aad62703144752597b4c))

## [1.13.3](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.13.2...1.13.3) (2022-08-12)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v1.25.0 ([7550cc8](https://github.com/gravitee-io/gravitee-cockpit-api/commit/7550cc8c9c4d1e6071d94fa560990462b79dd58d))

## [1.13.2](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.13.1...1.13.2) (2022-07-28)


### Bug Fixes

* **deps:** update io.gravitee.alert:gravitee-alert-api to v1.9.1 ([650341e](https://github.com/gravitee-io/gravitee-cockpit-api/commit/650341eeb34410010f496f053e252e4e0a612dd7))

## [1.13.1](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.13.0...1.13.1) (2022-06-23)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-parent to v20.3 ([f22c493](https://github.com/gravitee-io/gravitee-cockpit-api/commit/f22c4934e5a31cd57680d61ce230a8a8c1e0d5ec))

# [1.13.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.12.4...1.13.0) (2022-06-22)


### Features

* flag monitoring model as deprecated ([60bac86](https://github.com/gravitee-io/gravitee-cockpit-api/commit/60bac86ea9706d867d9da0b0855c962ae568ece9))

## [1.12.4](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.12.3...1.12.4) (2022-06-21)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-bom to v2.6 ([f51602c](https://github.com/gravitee-io/gravitee-cockpit-api/commit/f51602c973b2bc7c858661776d40c4284d5f2f2b))

## [1.12.3](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.12.2...1.12.3) (2022-06-09)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v1.24.2 ([9dc72c2](https://github.com/gravitee-io/gravitee-cockpit-api/commit/9dc72c2a2e3175b6d3bc8fa48775ef626d7acbaa))

## [1.12.2](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.12.1...1.12.2) (2022-06-09)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v1.24.1 ([7cfff88](https://github.com/gravitee-io/gravitee-cockpit-api/commit/7cfff889d9eb31ca98002778d7b15271134291d2))

## [1.12.1](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.12.0...1.12.1) (2022-05-27)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v1.24.0 ([13c68d9](https://github.com/gravitee-io/gravitee-cockpit-api/commit/13c68d9697f4c3e6ecb5d7fac4ac0c888f484d44))

# [1.12.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.11.1...1.12.0) (2022-05-16)


### Features

* add constants for installation type ([1a6a642](https://github.com/gravitee-io/gravitee-cockpit-api/commit/1a6a6426813868f06d6b2b782985a2c6e363b04b))

## [1.11.1](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.11.0...1.11.1) (2022-05-16)


### Bug Fixes

* **deps:** update io.gravitee.node:gravitee-node-api to v1.23.0 ([d985eb7](https://github.com/gravitee-io/gravitee-cockpit-api/commit/d985eb761849b04c49ee0fcdbe2a62e10e664ff4))

# [1.11.0](https://github.com/gravitee-io/gravitee-cockpit-api/compare/1.10.0...1.11.0) (2022-05-12)


### Bug Fixes

* **deps:** update io.gravitee:gravitee-bom to v2.4 ([24180d6](https://github.com/gravitee-io/gravitee-cockpit-api/commit/24180d683b43cfa76183799741220d69b3d75b17))
* **deps:** update io.gravitee:gravitee-bom to v2.5 ([b74b280](https://github.com/gravitee-io/gravitee-cockpit-api/commit/b74b280928db9899e8c002e7c9892e12acdf6274))
* **deps:** update io.gravitee.node:gravitee-node-api to v1.21.0 ([e9eb385](https://github.com/gravitee-io/gravitee-cockpit-api/commit/e9eb38579fd185907ad328d72b0a460bb234d66a))
* **deps:** update io.gravitee.node:gravitee-node-api to v1.21.1 ([12fd658](https://github.com/gravitee-io/gravitee-cockpit-api/commit/12fd658023ec1c128bf2991c882998cc3f101a4b))
* **deps:** update io.gravitee.node:gravitee-node-api to v1.22.0 ([7f157ca](https://github.com/gravitee-io/gravitee-cockpit-api/commit/7f157ca5edc31511de6e1d597a8c9919109459cd))


### Features

* add release script ([70c8e42](https://github.com/gravitee-io/gravitee-cockpit-api/commit/70c8e42323a5cc454c4309394351b9828e4e9c5c))
