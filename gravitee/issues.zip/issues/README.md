# Gravitee.io-wide Issues

We use this repository to host a GitHub issues that contains issues that pertain to Gravitee.io *as a whole* and not to any specific repository.

## Go to the [issues](https://github.com/gravitee-io/issues/issues)

# APIM changelog files

### ⚠️ Please note that the APIM changelog files has been moved [here](https://github.com/gravitee-io/gravitee-api-management/tree/master/release/changelog). ⚠️
You can also access the changelog from the [APIM documentation](https://docs.gravitee.io/apim/3.x/apim_changelog.html).
