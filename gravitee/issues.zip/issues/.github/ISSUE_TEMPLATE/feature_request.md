---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: 'type: feature'
assignees: ''

---

## :rainbow: Feature

**As a** '...'

**I want to** '...'

**So that** '...'

## :sunrise_over_mountains: Additional information

Detailed behaviour, rules or additional interesting stuffs...
Dependencies
Insert screenshots, drawings...
Documentation required (Provide link to the issue for documentation update)
Potential impacts

## :white_check_mark: Acceptance criteria

- [ ] Given '...' When '...' Then '...'


## :ballot_box_with_check: Developer sub-tasks 

- [ ] Jest test for acceptance criteria
